// Sample notification data
let notificationsData = [
    { text: "You have a new message", time: "2 min ago", isRead: false },
    { text: "Update: Project meeting tomorrow", time: "10 min ago", isRead: false },
    { text: "New comment on your post", time: "1 hr ago", isRead: true },
    { text: "Friend request accepted", time: "2 hrs ago", isRead: false },
];

const notificationsContainer = document.querySelector('.notifications');
const noNotificationsMessage = document.querySelector('.no-notifications');

function renderNotifications() {
    notificationsContainer.innerHTML = '';  // Clear previous notifications

    if (notificationsData.length === 0) {
        noNotificationsMessage.style.display = 'block';
    } else {
        noNotificationsMessage.style.display = 'none';
    }

    notificationsData.forEach((notification, index) => {
        const notificationItem = document.createElement('div');
        notificationItem.classList.add('notification-item');
        if (notification.isRead) notificationItem.classList.add('read');

        notificationItem.innerHTML = `
            <span class="notification-text">${notification.text}</span>
            <span class="notification-time">${notification.time}</span>
        `;

        notificationItem.onclick = () => markAsRead(index, notificationItem);
        notificationsContainer.appendChild(notificationItem);
    });
}

function markAsRead(index, element) {
    notificationsData[index].isRead = true;
    element.classList.add('read');
}

function markAllRead() {
    notificationsData.forEach(notification => notification.isRead = true);
    renderNotifications();
}

function clearAllNotifications() {
    notificationsData = [];
    renderNotifications();
}

// Initial rendering of notifications
renderNotifications();
