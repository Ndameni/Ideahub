document.addEventListener("DOMContentLoaded", () => {
    const editProfileBtn = document.querySelector(".edit-profile-btn");
    const modal = document.querySelector(".modal");
    const closeModalBtn = document.querySelector(".close-btn");
    const saveBtn = document.querySelector(".save-btn");

    const ideasCount = document.getElementById("ideas-count");
    const commentsCount = document.getElementById("comments-count");
    const thumbsUpCount = document.getElementById("thumbs-up-count");
    const thumbsDownCount = document.getElementById("thumbs-down-count");

    // Simulated data
    const userData = {
        name: "John Doe",
        email: "john.doe@example.com",
        password: "password123",
        profilePicture: "default-avatar.png",
        ideas: 3,
        comments: 5,
        thumbsUp: 12,
        thumbsDown: 2
    };

    // Function to update profile stats
    function updateProfileStats() {
        ideasCount.textContent = userData.ideas;
        commentsCount.textContent = userData.comments;
        thumbsUpCount.textContent = userData.thumbsUp;
        thumbsDownCount.textContent = userData.thumbsDown;
    }

    // Update the profile on page load
    updateProfileStats();

    // Toggle Modal Visibility
    function openModal() {
        modal.style.display = "flex";
    }

    function closeModal() {
        modal.style.display = "none";
    }

    // Edit Profile Button Click - Show Modal
    editProfileBtn.addEventListener("click", () => {
        openModal();
        // Pre-fill modal fields with user data
        document.getElementById("name-input").value = userData.name;
        document.getElementById("email-input").value = userData.email;
        document.getElementById("password-input").value = userData.password;
    });

    // Close Modal Button Click
    closeModalBtn.addEventListener("click", closeModal);

    // Save Changes in Modal (Form Submission)
    saveBtn.addEventListener("click", () => {
        // Retrieve new values from the modal form
        const newName = document.getElementById("name-input").value;
        const newEmail = document.getElementById("email-input").value;
        const newPassword = document.getElementById("password-input").value;

        // Simple validation (can be expanded as needed)
        if (newName && newEmail && newPassword) {
            userData.name = newName;
            userData.email = newEmail;
            userData.password = newPassword;

            // Update Profile Stats if needed (optional)
            updateProfileStats();

            // Update Profile UI
            document.querySelector(".profile-info h1").textContent = userData.name;
            document.querySelector(".profile-info p").textContent = `Email: ${userData.email}`;

            // Close Modal after saving
            closeModal();
        } else {
            alert("Please fill in all fields.");
        }
    });

    // Simulate profile picture upload (for demonstration)
    document.getElementById("profile-picture-input").addEventListener("change", (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function (e) {
                document.querySelector(".profile-avatar").src = e.target.result;
                userData.profilePicture = e.target.result; // Store the new profile picture
            };
            reader.readAsDataURL(file);
        }
    });
});

