// Set the Active Link Based on Current URL
document.addEventListener("DOMContentLoaded", function () {
    // Get all nav links
    const navLinks = document.querySelectorAll(".nav-link");

    // Loop through each link to find and set the active one
    navLinks.forEach(link => {
        // Check if the current page's URL matches the link's href
        if (link.href === window.location.href) {
            link.classList.add("active");
        } else {
            link.classList.remove("active");
        }
    });
});

// Download Data Functions
function downloadData() {
    alert("Initiating download for ideas data in CSV format...");
    // Additional code for CSV download functionality can go here
}

function downloadDocuments() {
    alert("Initiating download for all uploaded documents in ZIP format...");
    // Additional code for ZIP download functionality can go here
}
