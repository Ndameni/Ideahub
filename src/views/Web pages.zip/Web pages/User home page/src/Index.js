document.addEventListener("DOMContentLoaded", function() {
    const popularIdeas = [
        { id: 1, title: "Improve Teaching Facilities", thumbsUp: 150 },
        { id: 2, title: "Enhanced Research Funding", thumbsUp: 120 },
        { id: 3, title: "Staff Training Workshops", thumbsUp: 100 }
    ];

    const notifications = [
        { message: "New comment on your idea 'Improve Teaching Facilities'", timestamp: "2024-11-01 10:30" },
        { message: "Your idea 'Enhanced Research Funding' received a Thumbs Up!", timestamp: "2024-11-02 09:15" },
        { message: "New comment on your idea 'Staff Training Workshops'", timestamp: "2024-11-03 14:45" }
    ];

    const popularIdeasList = document.getElementById("popular-ideas-list");
    const notificationList = document.getElementById("notification-list");

    // Load popular ideas
    popularIdeas.forEach(idea => {
        const listItem = document.createElement("li");
        listItem.textContent = `${idea.title} - 👍 ${idea.thumbsUp}`;
        popularIdeasList.appendChild(listItem);
    });

    // Load notifications
    notifications.forEach(notification => {
        const listItem = document.createElement("li");
        listItem.textContent = `${notification.timestamp} - ${notification.message}`;
        notificationList.appendChild(listItem);
    });
});
