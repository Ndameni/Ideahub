// Example Data Initialization
let ideas = [
    { id: 1, title: "New Library System", category: "Infrastructure", upVotes: 25, downVotes: 2 },
    { id: 2, title: "Improve Cafeteria Food", category: "Services", upVotes: 15, downVotes: 5 },
];
let categories = ["Infrastructure", "Services", "Policy"];

// Load Initial Data
document.addEventListener("DOMContentLoaded", function () {
    loadIdeas();
    loadCategories();
    updateStats();
});

// Load Ideas
function loadIdeas(filterCategory = "") {
    const ideaList = document.getElementById("idea-list");
    ideaList.innerHTML = "";
    const filteredIdeas = filterCategory
        ? ideas.filter(idea => idea.category === filterCategory)
        : ideas;

    filteredIdeas.forEach(idea => {
        const ideaItem = document.createElement("div");
        ideaItem.className = "idea-item";
        ideaItem.innerHTML = `
            <h3>${idea.title}</h3>
            <p>Category: ${idea.category}</p>
            <p>Thumbs Up: ${idea.upVotes} | Thumbs Down: ${idea.downVotes}</p>
            <button onclick="disableIdea(${idea.id})">Disable</button>
        `;
        ideaList.appendChild(ideaItem);
    });
}

// Search Ideas
function searchIdeas() {
    const searchValue = document.getElementById("search-ideas").value.toLowerCase();
    const filteredIdeas = ideas.filter(idea => idea.title.toLowerCase().includes(searchValue));
    displayFilteredIdeas(filteredIdeas);
}

function displayFilteredIdeas(filteredIdeas) {
    const ideaList = document.getElementById("idea-list");
    ideaList.innerHTML = "";
    filteredIdeas.forEach(idea => {
        const ideaItem = document.createElement("div");
        ideaItem.className = "idea-item";
        ideaItem.innerHTML = `<h3>${idea.title}</h3><p>Category: ${idea.category}</p>`;
        ideaList.appendChild(ideaItem);
    });
}

// Load Categories
function loadCategories() {
    const categoryList = document.getElementById("category-list");
    const categoryFilter = document.getElementById("category-filter");
    categoryList.innerHTML = "";
    categoryFilter.innerHTML = `<option value="">All Categories</option>`;

    categories.forEach(category => {
        const categoryItem = document.createElement("li");
        categoryItem.className = "category-item";
        categoryItem.textContent = category;
        categoryList.appendChild(categoryItem);

        // Add to filter dropdown
        const option = document.createElement("option");
        option.value = category;
        option.textContent = category;
        categoryFilter.appendChild(option);
    });
}

// Filter Ideas by Category
function filterByCategory() {
    const selectedCategory = document.getElementById("category-filter").value;
    loadIdeas(selectedCategory);
}

// Add Category
function addCategory() {
    const newCategory = document.getElementById("new-category").value;
    if (newCategory && !categories.includes(newCategory)) {
        categories.push(newCategory);
        loadCategories();
    }
}

// Update Stats
function updateStats() {
    document.getElementById("total-ideas").textContent = ideas.length;
    document.getElementById("total-comments").textContent = ideas.reduce((acc, idea) => acc + (idea.comments || 0), 0);
    document.getElementById("thumbs-up").textContent = ideas.reduce((acc, idea) => acc + idea.upVotes, 0);
    document.getElementById("thumbs-down").textContent = ideas.reduce((acc, idea) => acc + idea.downVotes, 0);
}

// Disable Idea
function disableIdea(id) {
    ideas = ideas.filter(idea => idea.id !== id);
    loadIdeas();
    updateStats();
}

// Generate Analytics
function generateAnalytics() {
    document.getElementById("analytics-output").textContent = "Generated analytics data based on idea submissions...";
}

// Download CSV
function downloadCSV() {
    alert("CSV data download triggered.");
}

// Download ZIP
function downloadZip() {
    alert("ZIP document download triggered.");
}
