// JavaScript for form submission
document.getElementById("idea-form").addEventListener("submit", function (event) {
  event.preventDefault();

  // Fetch form data
  const title = document.getElementById("idea-title").value;
  const description = document.getElementById("idea-description").value;
  const category = document.getElementById("idea-category").value;
  const anonymous = document.getElementById("anonymous").checked;
  const agreeTerms = document.getElementById("agree-terms").checked;
  const file = document.getElementById("idea-file").files[0];

  // Check required fields
  if (title && description && category && agreeTerms) {
    alert("Your idea has been submitted successfully!");

    // Reset form after submission
    document.getElementById("idea-form").reset();
  } else {
    alert("Please fill out all required fields and agree to the terms.");
  }
});