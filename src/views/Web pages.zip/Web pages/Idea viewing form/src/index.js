let upCount = 12;
let downCount = 3;

function initializeFeedback() {
    document.getElementById("up-count").innerText = upCount;
    document.getElementById("down-count").innerText = downCount;

    if (localStorage.getItem("ideaVotedUp")) {
        disableButton("thumbs-up");
    }
    if (localStorage.getItem("ideaVotedDown")) {
        disableButton("thumbs-down");
    }
}

function disableButton(buttonId) {
    const button = document.getElementById(buttonId);
    button.disabled = true;
    button.classList.add("disabled");
}

function likeIdea() {
    if (!localStorage.getItem("ideaVotedUp")) {
        upCount++;
        document.getElementById("up-count").innerText = upCount;
        localStorage.setItem("ideaVotedUp", "true");
        disableButton("thumbs-up");
    } else {
        alert("You have already given a thumbs up for this idea.");
    }
}

function dislikeIdea() {
    if (!localStorage.getItem("ideaVotedDown")) {
        downCount++;
        document.getElementById("down-count").innerText = downCount;
        localStorage.setItem("ideaVotedDown", "true");
        disableButton("thumbs-down");
    } else {
        alert("You have already given a thumbs down for this idea.");
    }
}

function postComment() {
    const commentText = document.getElementById("comment-text").value.trim();
    const anonymous = document.getElementById("anonymous-comment").checked;

    if (commentText) {
        addComment(commentText, anonymous);
        document.getElementById("comment-text").value = "";
    } else {
        alert("Please enter a comment before submitting.");
    }
}

function addComment(text, isAnonymous) {
    const commentsSection = document.querySelector(".comments-section");
    const commentDiv = document.createElement("div");
    commentDiv.classList.add("comment");

    const authorName = isAnonymous ? "(Anonymous)" : "Your Name";
    const currentDate = new Date().toLocaleDateString();

    commentDiv.innerHTML = `
        <p><strong>${authorName}</strong> - ${currentDate}</p>
        <p>${text}</p>
    `;

    commentsSection.insertBefore(commentDiv, commentsSection.querySelector(".comment-form"));
}

document.addEventListener("DOMContentLoaded", initializeFeedback);
